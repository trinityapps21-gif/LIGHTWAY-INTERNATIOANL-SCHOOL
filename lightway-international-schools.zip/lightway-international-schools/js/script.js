/* =========================================================
   LIGHTWAY INTERNATIONAL SCHOOLS – Shared JavaScript
   1. Mobile navigation
   2. Scroll-reveal animations
   3. Contact form validation + submission
   ========================================================= */

(function () {
  "use strict";

  document.documentElement.classList.remove("no-js");

  /* ---------- 1. Mobile navigation ---------- */
  var toggle = document.querySelector(".nav-toggle");
  var nav = document.getElementById("main-nav");

  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
    });
    // Close the menu after choosing a link
    nav.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        nav.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
      });
    });
    // Close with the Escape key
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && nav.classList.contains("open")) {
        nav.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
        toggle.focus();
      }
    });
  }

  /* ---------- 2. Scroll reveal (staggered) ---------- */
  var revealEls = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("in");
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });

    revealEls.forEach(function (el) {
      // Stagger siblings inside the same grid
      var parent = el.parentElement;
      if (parent && (parent.classList.contains("grid") || parent.classList.contains("journey") || parent.classList.contains("rel"))) {
        var index = Array.prototype.indexOf.call(parent.children, el);
        el.style.setProperty("--d", (index * 0.1) + "s");
      }
      io.observe(el);
    });
  } else {
    revealEls.forEach(function (el) { el.classList.add("in"); });
  }

  /* ---------- 3. Contact form ---------- */
  var form = document.getElementById("contact-form");
  if (!form) { return; }

  /*
   * HOW TO RECEIVE REAL ENQUIRIES
   * -----------------------------
   * 1. Create a free form at https://formspree.io using osona8810@gmail.com
   * 2. Copy your form URL (looks like https://formspree.io/f/abcdwxyz)
   * 3. Paste it between the quotes below and save.
   * Until this is set the form runs in DEMO mode and does NOT send anything.
   */
  var FORM_ENDPOINT = "";
  var SCHOOL_EMAIL = "osona8810@gmail.com";

  var status = document.getElementById("form-status");
  var submitBtn = form.querySelector("button[type='submit']");
  var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  function showStatus(type, html) {
    status.className = "form-status show " + type;
    status.innerHTML = html;
    status.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  function validateField(input) {
    var wrap = input.closest(".field");
    var value = input.value.trim();
    var msg = wrap.querySelector(".err");
    var ok = true;

    if (input.required && !value) {
      ok = false;
      msg.textContent = "Please fill in this field.";
    } else if (input.type === "email" && value && !emailPattern.test(value)) {
      ok = false;
      msg.textContent = "Please enter a valid email address, e.g. name@example.com.";
    } else if (input.name === "message" && value && value.length < 10) {
      ok = false;
      msg.textContent = "Please write at least 10 characters so we can help you.";
    }
    wrap.classList.toggle("invalid", !ok);
    input.setAttribute("aria-invalid", String(!ok));
    return ok;
  }

  form.querySelectorAll("input, textarea").forEach(function (input) {
    input.addEventListener("blur", function () { validateField(input); });
    input.addEventListener("input", function () {
      if (input.closest(".field").classList.contains("invalid")) { validateField(input); }
    });
  });

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    // Honeypot: bots fill this hidden field
    if (form.elements["_gotcha"] && form.elements["_gotcha"].value) { return; }

    var fields = form.querySelectorAll("input[required], textarea[required]");
    var allValid = true;
    var firstBad = null;
    fields.forEach(function (f) {
      if (!validateField(f)) { allValid = false; if (!firstBad) { firstBad = f; } }
    });
    if (!allValid) {
      showStatus("error", "<strong>Please check the form.</strong> Some fields need your attention.");
      firstBad.focus();
      return;
    }

    var data = {
      name: form.elements["name"].value.trim(),
      email: form.elements["email"].value.trim(),
      subject: form.elements["subject"].value.trim(),
      message: form.elements["message"].value.trim()
    };

    // DEMO mode: no backend configured. Be honest and offer the email fallback.
    if (!FORM_ENDPOINT) {
      var mailto = "mailto:" + SCHOOL_EMAIL +
        "?subject=" + encodeURIComponent(data.subject) +
        "&body=" + encodeURIComponent(data.message + "\n\n— " + data.name + " (" + data.email + ")");
      showStatus("info",
        "<strong>Demo mode – your message has not been sent.</strong> This form is not yet connected to an email service. " +
        "To contact us now, <a href=\"" + mailto + "\">click here to send it from your email app</a> " +
        "or write to <a href=\"mailto:" + SCHOOL_EMAIL + "\">" + SCHOOL_EMAIL + "</a>.");
      return;
    }

    // LIVE mode: send to the configured form service
    submitBtn.disabled = true;
    var originalLabel = submitBtn.textContent;
    submitBtn.textContent = "Sending…";

    fetch(FORM_ENDPOINT, {
      method: "POST",
      headers: { "Accept": "application/json", "Content-Type": "application/json" },
      body: JSON.stringify(data)
    }).then(function (res) {
      if (res.ok) {
        form.reset();
        showStatus("success", "<strong>Thank you, " + data.name.replace(/[<>&]/g, "") + ".</strong> Your message has been sent. We will get back to you soon.");
      } else {
        throw new Error("Server responded " + res.status);
      }
    }).catch(function () {
      showStatus("error",
        "<strong>Sorry, we could not send your message.</strong> Please try again, or email us directly at " +
        "<a href=\"mailto:" + SCHOOL_EMAIL + "\">" + SCHOOL_EMAIL + "</a>.");
    }).then(function () {
      submitBtn.disabled = false;
      submitBtn.textContent = originalLabel;
    });
  });
})();
